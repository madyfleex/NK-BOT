[
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvMRPeHtlg3wipWxCS055lBMcQpYn2Pogdyw&usqp=CAU"},
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZwjGF4urnf7AI5zVNIaZvbGHtt3u--CzBDw&usqp=CAU"}
]
